package application;
	
	
import java.sql.*;
import java.util.*;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;


public class Main extends Application {
	Stage window;
	Scene scene0,scene1,scene2,scene3,scene4,scene5,scene6,scene7;
	Label scorelabel1 = new Label("Score: 0/25");
	Label scorelabel2 = new Label();
	Label scorelabel3 = new Label();
	Label scorelabel4 = new Label();
	Label scorelabel5 = new Label();
	Label DisplayFinalScore = new Label("          ");
	int score=0;
	String Playername;
	@Override
	public void start(Stage primaryStage) {
		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/flashcardgame";
			String user = "root";
			String password = "";
			Connection c = DriverManager.getConnection(url, user, password) ;
			Statement stmt = c.createStatement();
			ResultSet rs = stmt.executeQuery("select * from animalnames");
			
			List<String> AnimalList = new ArrayList();
	        int i=0;
			while(rs.next())
			{
				AnimalList.add(rs.getString("name"));
				i++;
			}
			Collections.shuffle(AnimalList);
		
			Alert ShowAlert = new Alert(AlertType.NONE); 
			
			window = primaryStage;
			//HomePage
			Label question1 = new Label("Question 1:");
			Label question2 = new Label("Question 2:");
			Label question3 = new Label("Question 3:");
			Label question4 = new Label("Question 4:");
			Label question5 = new Label("Question 5:");
			Label pname = new Label("Enter Player Name : ");
			TextField playernametext = new TextField();
			playernametext.setPromptText("Enter Player Name");
			Button Start = new Button("Start Game");
			Start.setOnAction(e ->{ 
				if((playernametext.getText()).isEmpty())
				{
					ShowAlert.setAlertType(AlertType.INFORMATION);ShowAlert.setContentText("Please Enter the username first");ShowAlert.show();
					window.setScene(scene0);
				}
				else
				{
					playernametext.clear();
					Playername = playernametext.getText();
					window.setScene(scene1);
				}
				
				
			});
			Button crud = new Button("Database Operation");
			crud.setOnAction(e ->{window.setScene(scene7);});
			
			HBox HomePagelayout= new HBox(pname,playernametext);
			HomePagelayout.setPadding(new Insets(100, 20, 10, 100));
			HBox layout= new HBox(Start,crud);
			layout.setSpacing(10);
			layout.setPadding(new Insets(50, 20, 10, 150));
			FlowPane root0 = new FlowPane();
			root0.getChildren().add(HomePagelayout);
			root0.getChildren().add(layout);
			scene0 = new Scene(root0,600,400);
	
			//Question 1
			
			String animal1 = AnimalList.get(0);
			
			Label animalname1 = new Label(animal1.toUpperCase()+"    ");
			
			animalname1.setFont(new Font("Arial", 50));
			Button FirstScore1 = new Button("0");
			
			FirstScore1.setOnAction(e ->{score=0; score+=0;scorelabel2.setText("Score: "+score+"/25");ShowAlert.setAlertType(AlertType.INFORMATION);ShowAlert.setContentText("Very Poor");ShowAlert.show();window.setScene(scene2); });
			Button FirstScore2 = new Button("1");
		
			FirstScore2.setOnAction(e ->{score=0; score+=1;scorelabel2.setText("Score: "+score+"/25");ShowAlert.setAlertType(AlertType.INFORMATION);ShowAlert.setContentText("Poor" );ShowAlert.show();window.setScene(scene2);});
			Button FirstScore3 = new Button("2");
			FirstScore3.setOnAction(e ->{score=0; score+=2;scorelabel2.setText("Score: "+score+"/25");ShowAlert.setAlertType(AlertType.INFORMATION);ShowAlert.setContentText("You Are Getting It" );ShowAlert.show();window.setScene(scene2);});
			Button FirstScore4 = new Button("3");
			FirstScore4.setOnAction(e ->{score=0; score+=3;scorelabel2.setText("Score: "+score+"/25");ShowAlert.setAlertType(AlertType.INFORMATION);ShowAlert.setContentText("Good" );ShowAlert.show();window.setScene(scene2);});
			Button FirstScore5 = new Button("4");
			FirstScore5.setOnAction(e ->{score=0; score+=4;scorelabel2.setText("Score: "+score+"/25");ShowAlert.setAlertType(AlertType.INFORMATION);ShowAlert.setContentText("Very Good" );ShowAlert.show();window.setScene(scene2);});
			Button FirstScore6 = new Button("5");
			FirstScore6.setOnAction(e ->{score=0; score+=5;scorelabel2.setText("Score: "+score+"/25");ShowAlert.setAlertType(AlertType.INFORMATION);ShowAlert.setContentText("Excellent" );ShowAlert.show();window.setScene(scene2);});
			
			HBox question1layout= new HBox(FirstScore1,FirstScore2,FirstScore3,FirstScore4,FirstScore5,FirstScore6);
			question1layout.setSpacing(100);
			question1layout.setPadding(new Insets(50));
			animalname1.setTranslateX(330);
			VBox vbox = new VBox(question1,animalname1);
			vbox.setSpacing(10);
			
			FlowPane root1 = new FlowPane();
			root1.getChildren().add(vbox);
			root1.getChildren().add(question1layout);
			root1.getChildren().add(scorelabel1);
			scene1 = new Scene(root1,800,600);
			
			//Question2

			String animal2 = AnimalList.get(1);
			
			
			Label animalname2 = new Label(animal2.toUpperCase()+"    ");
			animalname2.setFont(new Font("Arial", 50));
			
			Button SecondScore1 = new Button("0");
			SecondScore1.setOnAction(e ->{ score+=0;scorelabel3.setText("Score: "+score+"/25");ShowAlert.setAlertType(AlertType.INFORMATION);ShowAlert.setContentText("Very Poor" );ShowAlert.show();window.setScene(scene3);});
			Button SecondScore2 = new Button("1");
			SecondScore2.setOnAction(e ->{ score+=1;scorelabel3.setText("Score: "+score+"/25");ShowAlert.setAlertType(AlertType.INFORMATION);ShowAlert.setContentText("Poor" );ShowAlert.show();window.setScene(scene3);});
			Button SecondScore3 = new Button("2");
			SecondScore3.setOnAction(e ->{ score+=2;scorelabel3.setText("Score: "+score+"/25");ShowAlert.setAlertType(AlertType.INFORMATION);ShowAlert.setContentText("You Are Getting It" );ShowAlert.show();window.setScene(scene3);});
			Button SecondScore4 = new Button("3");
			SecondScore4.setOnAction(e ->{ score+=3;scorelabel3.setText("Score: "+score+"/25");ShowAlert.setAlertType(AlertType.INFORMATION);ShowAlert.setContentText("Good" );ShowAlert.show();window.setScene(scene3);});
			Button SecondScore5 = new Button("4");
			SecondScore5.setOnAction(e ->{ score+=4;scorelabel3.setText("Score: "+score+"/25");ShowAlert.setAlertType(AlertType.INFORMATION);ShowAlert.setContentText("Very Good" );ShowAlert.show();window.setScene(scene3);});
			Button SecondScore6 = new Button("5");
			SecondScore6.setOnAction(e ->{ score+=5;scorelabel3.setText("Score: "+score+"/25");ShowAlert.setAlertType(AlertType.INFORMATION);ShowAlert.setContentText("Excellent" );ShowAlert.show();window.setScene(scene3);});
			
			HBox question2layout= new HBox(SecondScore1,SecondScore2,SecondScore3,SecondScore4,SecondScore5,SecondScore6);
			question2layout.setSpacing(100);
			question2layout.setPadding(new Insets(50));
			animalname2.setTranslateX(330);
			VBox vbox2 = new VBox(question2,animalname2);
			vbox2.setSpacing(10);
			
			FlowPane root2 = new FlowPane();
			root2.getChildren().add(vbox2);
			root2.getChildren().add(question2layout);
			root2.getChildren().add(scorelabel2);
			scene2 = new Scene(root2,800,600);
		
			//Question3
			
			String animal3 = AnimalList.get(2);
			
			
			Label animalname3 = new Label(animal3.toUpperCase()+"    ");
			animalname3.setFont(new Font("Arial", 50));
			Button speak2 = new Button("Speak");
			speak2.setTranslateX(250);
			speak2.setTranslateY(100);
			Button ThirdScore1 = new Button("0");
			ThirdScore1.setOnAction(e ->{ score+=0;scorelabel4.setText("Score: "+score+"/25");ShowAlert.setAlertType(AlertType.INFORMATION);ShowAlert.setContentText("Very Poor" );ShowAlert.show();window.setScene(scene4);});
			Button ThirdScore2 = new Button("1");
			ThirdScore2.setOnAction(e ->{ score+=1;scorelabel4.setText("Score: "+score+"/25");ShowAlert.setAlertType(AlertType.INFORMATION);ShowAlert.setContentText("Poor" );ShowAlert.show();window.setScene(scene4);});
			Button ThirdScore3 = new Button("2");
			ThirdScore3.setOnAction(e ->{ score+=2;scorelabel4.setText("Score: "+score+"/25");ShowAlert.setAlertType(AlertType.INFORMATION);ShowAlert.setContentText("You Are Getting It" );ShowAlert.show();window.setScene(scene4);});
			Button ThirdScore4 = new Button("3");
			ThirdScore4.setOnAction(e ->{ score+=3;scorelabel4.setText("Score: "+score+"/25");ShowAlert.setAlertType(AlertType.INFORMATION);ShowAlert.setContentText("Good" );ShowAlert.show();window.setScene(scene4);});
			Button ThirdScore5 = new Button("4");
			ThirdScore5.setOnAction(e ->{ score+=4;scorelabel4.setText("Score: "+score+"/25");ShowAlert.setAlertType(AlertType.INFORMATION);ShowAlert.setContentText("Very Good" );ShowAlert.show();window.setScene(scene4);});
			Button ThirdScore6 = new Button("5");
			ThirdScore6.setOnAction(e ->{ score+=5;scorelabel4.setText("Score: "+score+"/25");ShowAlert.setAlertType(AlertType.INFORMATION);ShowAlert.setContentText("Excellent" );ShowAlert.show();window.setScene(scene4);});
			
			HBox question3layout= new HBox(ThirdScore1,ThirdScore2,ThirdScore3,ThirdScore4,ThirdScore5,ThirdScore6);
			question3layout.setSpacing(100);
			question3layout.setPadding(new Insets(50));
			animalname3.setTranslateX(330);
			VBox vbox3 = new VBox(question3,animalname3);
			vbox3.setSpacing(10);
			
			FlowPane root3 = new FlowPane();
			root3.getChildren().add(vbox3);
			root3.getChildren().add(question3layout);
			root3.getChildren().add(scorelabel3);
			scene3 = new Scene(root3,800,600);
			
			//Question4
			
			String animal4 = AnimalList.get(3);
			
		
			Label animalname4 = new Label(animal4.toUpperCase()+"    ");
			animalname4.setFont(new Font("Arial", 50));
			Button speak3 = new Button("Speak");
			speak3.setTranslateX(250);
			speak3.setTranslateY(100);
			Button FourthScore1 = new Button("0");
			FourthScore1.setOnAction(e ->{ score+=0;scorelabel5.setText("Score: "+score+"/25");ShowAlert.setAlertType(AlertType.INFORMATION);ShowAlert.setContentText("Very Poor" );ShowAlert.show();window.setScene(scene5);});
			Button FourthScore2 = new Button("1");
			FourthScore2.setOnAction(e ->{ score+=1;scorelabel5.setText("Score: "+score+"/25");ShowAlert.setAlertType(AlertType.INFORMATION);ShowAlert.setContentText("Poor" );ShowAlert.show();window.setScene(scene5);});
			Button FourthScore3 = new Button("2");
			FourthScore3.setOnAction(e ->{ score+=2;scorelabel5.setText("Score: "+score+"/25");ShowAlert.setAlertType(AlertType.INFORMATION);ShowAlert.setContentText("You Are Getting It" );ShowAlert.show();window.setScene(scene5);});
			Button FourthScore4 = new Button("3");
			FourthScore4.setOnAction(e ->{ score+=3;scorelabel5.setText("Score: "+score+"/25");ShowAlert.setAlertType(AlertType.INFORMATION);ShowAlert.setContentText("Good" );ShowAlert.show();window.setScene(scene5);});
			Button FourthScore5 = new Button("4");
			FourthScore5.setOnAction(e ->{ score+=4;scorelabel5.setText("Score: "+score+"/25");ShowAlert.setAlertType(AlertType.INFORMATION);ShowAlert.setContentText("Very Good" );ShowAlert.show();window.setScene(scene5);});
			Button FourthScore6 = new Button("5");
			FourthScore6.setOnAction(e ->{ score+=5;scorelabel5.setText("Score: "+score+"/25");ShowAlert.setAlertType(AlertType.INFORMATION);ShowAlert.setContentText("Excellent" );ShowAlert.show();window.setScene(scene5);});
			
			HBox question4layout= new HBox(FourthScore1,FourthScore2,FourthScore3,FourthScore4,FourthScore5,FourthScore6);
			question4layout.setSpacing(100);
			question4layout.setPadding(new Insets(50));
			animalname4.setTranslateX(330);
			VBox vbox4 = new VBox(question4,animalname4);
			vbox4.setSpacing(10);
			
			FlowPane root4 = new FlowPane();
			root4.getChildren().add(vbox4);
			root4.getChildren().add(question4layout);
			root4.getChildren().add(scorelabel4);
			scene4 = new Scene(root4,800,600);
			
			//Question 5
			
			String animal5 = AnimalList.get(4);
			
	
			Label animalname5 = new Label(animal5.toUpperCase()+"    ");
			animalname5.setFont(new Font("Arial", 50));
			Button speak4 = new Button("Speak");
			speak4.setTranslateX(250);
			speak4.setTranslateY(100);
			Button FifthScore1 = new Button("0");
			FifthScore1.setOnAction(e ->{ score+=0;ShowAlert.setAlertType(AlertType.INFORMATION);ShowAlert.setContentText("Very Poor" );ShowAlert.show();window.setScene(scene6);});
			Button FifthScore2 = new Button("1");
			FifthScore2.setOnAction(e ->{ score+=1;ShowAlert.setAlertType(AlertType.INFORMATION);ShowAlert.setContentText("Poor" );ShowAlert.show();window.setScene(scene6);});
			Button FifthScore3 = new Button("2");
			FifthScore3.setOnAction(e ->{ score+=2;ShowAlert.setAlertType(AlertType.INFORMATION);ShowAlert.setContentText("You Are Getting It" );ShowAlert.show();window.setScene(scene6);});
			Button FifthScore4 = new Button("3");
			FifthScore4.setOnAction(e ->{ score+=3;ShowAlert.setAlertType(AlertType.INFORMATION);ShowAlert.setContentText("Good" );ShowAlert.show();window.setScene(scene6);});
			Button FifthScore5 = new Button("4");
			FifthScore5.setOnAction(e ->{ score+=4;ShowAlert.setAlertType(AlertType.INFORMATION);ShowAlert.setContentText("Very Good" );ShowAlert.show();window.setScene(scene6);});
			Button FifthScore6 = new Button("5");
			FifthScore6.setOnAction(e ->{ score+=5;ShowAlert.setAlertType(AlertType.INFORMATION);ShowAlert.setContentText("Excellent" );ShowAlert.show();window.setScene(scene6);});
			
			HBox question5layout= new HBox(FifthScore1,FifthScore2,FifthScore3,FifthScore4,FifthScore5,FifthScore6);
			question5layout.setSpacing(100);
			question5layout.setPadding(new Insets(50));
			animalname5.setTranslateX(330);
			VBox vbox5 = new VBox(question5,animalname5);
			vbox5.setSpacing(10);
			
			FlowPane root5 = new FlowPane();
			root5.getChildren().add(vbox5);
			root5.getChildren().add(question5layout);
			root5.getChildren().add(scorelabel5);
			scene5 = new Scene(root5,800,600);
			
			//Scene to Display the Score
			
			Button ScoreButton = new Button("See Your Final Score");
			ScoreButton.setOnAction(e ->{
				DisplayFinalScore.setFont(new Font("Arial", 30));
				String FinalScore = Playername+" Your Final Score is  "+score+"/25";
				DisplayFinalScore.setText(FinalScore);
				PreparedStatement addStatement = null;
				String name = Playername;
				int finalscore = score;
				try {
					String query = "insert into playername(name,score) values (?,?)";
					addStatement = c.prepareStatement(query);
					addStatement.setString(1, name);
					addStatement.setInt(2, finalscore);
					addStatement.executeUpdate();
					ShowAlert.setAlertType(AlertType.INFORMATION);
					ShowAlert.setContentText("Player name and score added  Successfully to database");
					ShowAlert.show();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				});
			Button GoToHome = new Button("Home Page");
			GoToHome.setOnAction(e ->{Collections.shuffle(AnimalList); window.setScene(scene0);});
			
			
			
			HBox scorelayout= new HBox(ScoreButton,GoToHome);
			scorelayout.setPadding(new Insets(200, 20, 10, 250));
			DisplayFinalScore.setPadding(new Insets(100, 20, 10, 200));
			scorelayout.setSpacing(30);
			FlowPane root6 = new FlowPane();
			root6.getChildren().add(DisplayFinalScore);
			root6.getChildren().add(scorelayout);
			scene6 = new Scene(root6,800,600);
			
			//CRUD Operation on the database
			Label aname = new Label("Enter Animal Name : ");
			TextField animalnameTextField = new TextField();
			animalnameTextField.setPromptText("Animal Name TO Insert/Delete/Update");
			TextField toupdate = new TextField();
			toupdate.setPromptText("Animal to update with");
			Button AddToDatabase = new Button("AddToDatabase");
			AddToDatabase.setOnAction(e ->{ 
				if((animalnameTextField.getText()).isEmpty())
				{
					ShowAlert.setAlertType(AlertType.INFORMATION);ShowAlert.setContentText("Please Enter Animal to be Added\nDeleted\nUpdated");ShowAlert.show();
					window.setScene(scene7);
				}
				else
				{
				PreparedStatement addStatement = null;
				String name = animalnameTextField.getText();
				try {
					String query = "insert into animalnames(name) values (?)";
					addStatement = c.prepareStatement(query);
					addStatement.setString(1, name);
					addStatement.executeUpdate();
					ShowAlert.setAlertType(AlertType.INFORMATION);
					ShowAlert.setContentText("Animal Added");
					ShowAlert.show();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				animalnameTextField.clear();
				toupdate.clear();
				window.setScene(scene0);
				}
			});
			Button DeleteFromDatabase = new Button("Delete");
			DeleteFromDatabase.setOnAction(e ->{ 
				if((animalnameTextField.getText()).isEmpty())
				{
					ShowAlert.setAlertType(AlertType.INFORMATION);ShowAlert.setContentText("Please Enter Animal to be Added\nDeleted\nUpdated");ShowAlert.show();
					window.setScene(scene7);
				}
				else
				{
				PreparedStatement delStatement = null;
				String name = animalnameTextField.getText();
				try {
					String query = "delete from animalnames where name=?";
					delStatement = c.prepareStatement(query);
					delStatement.setString(1, name);
					delStatement.executeUpdate();
					ShowAlert.setAlertType(AlertType.INFORMATION);
					ShowAlert.setContentText("Animal Deleted");
					ShowAlert.show();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				animalnameTextField.clear();
				toupdate.clear();
				window.setScene(scene0);
				}
			});
			Button UpdateToDatabase = new Button("Update");
			UpdateToDatabase.setOnAction(e ->{ 
				if((animalnameTextField.getText()).isEmpty())
				{
					ShowAlert.setAlertType(AlertType.INFORMATION);ShowAlert.setContentText("Please Enter Animal to be Added\nDeleted\nUpdated");ShowAlert.show();
					window.setScene(scene7);
				}
				else
				{
					if((toupdate.getText()).isEmpty())
					{
						ShowAlert.setAlertType(AlertType.INFORMATION);ShowAlert.setContentText("Please Enter Animal to update with");ShowAlert.show();
						window.setScene(scene7);
					}
					else
					{
					PreparedStatement updateStatement = null;
					String name = animalnameTextField.getText();
					String to = toupdate.getText();
					try {
						String query = "update animalnames set name=? where name=?";
						updateStatement = c.prepareStatement(query);
						updateStatement.setString(1, to);
						updateStatement.setString(2, name);
						updateStatement.executeUpdate();
						ShowAlert.setAlertType(AlertType.INFORMATION);
						ShowAlert.setContentText("Updated Successfully");
						ShowAlert.show();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					animalnameTextField.clear();
					toupdate.clear();
					window.setScene(scene0);
					}
				}
			});
			Button GoToHome1 = new Button("Home Page");
			GoToHome1.setOnAction(e ->{ window.setScene(scene0);});
			
			HBox CRUDlayout1= new HBox(aname,animalnameTextField,toupdate);
			CRUDlayout1.setSpacing(20);
			CRUDlayout1.setPadding(new Insets(200, 20, 10, 150));
			HBox CRUDlayout2= new HBox(AddToDatabase,DeleteFromDatabase,UpdateToDatabase,GoToHome1);
			CRUDlayout2.setSpacing(10);
			CRUDlayout2.setPadding(new Insets(50, 20, 10, 220));
			FlowPane root7 = new FlowPane();
			root7.getChildren().add(CRUDlayout1);
			root7.getChildren().add(CRUDlayout2);
			//root5.getChildren().add(question5layout);
			//root5.getChildren().add(scorelabel5);
			scene7 = new Scene(root7,800,600);
			
			//Initial Scene Display
			window.setScene(scene0);
			window.show();
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
